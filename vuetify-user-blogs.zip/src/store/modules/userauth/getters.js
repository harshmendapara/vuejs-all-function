export default {
  userLoggedIn (state) {
    return state.userLoggedIn
  }
}
