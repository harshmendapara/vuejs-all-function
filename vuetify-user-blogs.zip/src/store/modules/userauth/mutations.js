import { set } from '../../../utils/vuex'

export default {
  loginStatus: set('userLoggedIn')
}
